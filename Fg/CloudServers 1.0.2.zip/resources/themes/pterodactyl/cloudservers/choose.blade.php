{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.master')

@section('title')
    Choose
@endsection

@section('content-header')
<h1 style="margin-top: 1%; text-align: center;"><strong>CHOOSE</strong></h1>
<h4 style="text-align: center; color: gray;">CHOOSE THE TYPE SERVER YOU WANT</h4>
@endsection

@section('content')
        <div class="row" style="display: block; align-items: center; justify-content: center;">
@foreach($eggs as $egg)
    @if($egg->status == 1)
        <div class="col-md-4">
    <div class="box">
        <div class="box-body">
            <div class="row">
                <div class="col-md-4">
                    <img src="{{ $egg->img }}" width="125" alt="-" />
                </div>
                <div class="col-md-8" style="margin-top: 1%;"><br><br>
                    <div class="row">
                    <div class="col-md-8">
                    <h4>{{ $egg->name }}</h4>
                    </div>
                    <div class="col-md-4">
                    <form action="{{ route('cloudservers.game', $egg->id) }}">
                    @csrf<button class="btn btn-primary">Create</button>
                    </form>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endif
@endforeach
@endsection

@section('footer-scripts')
    @parent
    <script>
        $('tr.server-description').on('mouseenter mouseleave', function (event) {
            $(this).prev('tr').css({
                'background-color': (event.type === 'mouseenter') ? '#f5f5f5' : '',
            });
        });
    </script>

<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script>
$(document).ready(function(){
    $("select.type").change(function(){
        var type = $(this).children("option:selected").val();
    });

    document.getElementById("type").innerHTML = window.carName;
});
</script>
    {!! Theme::js('js/frontend/serverlist.js') !!}
@endsection

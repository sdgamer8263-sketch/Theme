{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.master')

@section('title')
    Addons
@endsection

@section('content-header')
<style>
.red {
    color: red;
}
</style>
<h1 style="margin-top: 1%; text-align: center;"><strong>SETTINGS</strong></h1>
<h4 style="text-align: center; color: gray;">CHOOSE THE SETTINGS FOR YOUR SERVER</h4>
@endsection

@section('content')
<form method="POST" action="{{ route('cloudservers.game.create', $id) }}">
<div class="box">
    <div class="box-body">
        <div class="row">
            <div class="col-md-12">
                <h4 style="color: black;">Server Name</h4>
                <input name="name" value="Server Name" class="form-control"></input>
                <p>Chouse your server name here</p>
            </div>
            <br>
            <div class="col-md-12">
                <h4 style="color: black;">Description</h4>
                <textarea name="desc" row="4" value="Server Name" class="form-control"></textarea>
                <p>The description of your server</p>
            </div>
            <div class="col-md-4">
                <h4 style="color: black;">Type</h4>
                <select name="type" disabled="disabled" class="form-control">
                @foreach($eggs as $egg)
                <option selected value="{{ $egg->id }}">{{ $egg->name }}</option>
                @endforeach
                </select>
            </div>
            <div class="col-md-4">
                <h4 style="color: black;">Ram</h4>
                <input name="ram" id='ram' type="number" value="0" class="form-control"></input>
                @foreach($users as $user)
                <p style="text-align: center; color: gray;"><strong>YOU HAVE</strong> <span id='ramcolor' style="color: black;"><input style="background: transparent; border: none; width: 9%;" type='text' value="{{ $user->ram }}" id='ram2'></input>MB</span> <strong>RAM LEFT</strong></p>
                @endforeach
            </div>
            <div class="col-md-4">
                <h4 style="color: black;">Disk</h4>
                <input name="disk" id='disk' type="number" value="0" class="form-control"></input>
                @foreach($users as $user)
                <p style="text-align: center; color: gray;"><strong>YOU HAVE</strong> <span style="color: black;"><input style="background: transparent; border: none; width: 9%;" type='text' value="{{ $user->disk }}" id='disk2'></input>MB</span> <strong>DISK LEFT</strong></p>
                @endforeach
            </div>
        </div>
        @csrf<button style="width: 100%; margin-top: 2%;" class="btn btn-success">Create</button>
    </div>
</div>
</form>
@endsection

@section('footer-scripts')
    @parent
    <script>
        $('tr.server-description').on('mouseenter mouseleave', function (event) {
            $(this).prev('tr').css({
                'background-color': (event.type === 'mouseenter') ? '#f5f5f5' : '',
            });
        });
        var d = document.getElementById("div1");

    </script>

<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script>
var inputBox = document.getElementById('disk');

inputBox.onkeyup = function(){
    document.getElementById('disk2').innerHTML = inputBox.value;
   var val = <?php echo $user->disk ?> - document.getElementById('disk').value;
  document.getElementById('disk2').value = val;
}

var inputBox2 = document.getElementById('ram');

inputBox2.onkeyup = function(){
    document.getElementById('ram2').innerHTML = inputBox2.value;
   var val = <?php echo $user->ram ?> - document.getElementById('ram').value;
  document.getElementById('ram2').value = val;
}
</script>
<script>
$(document).ready(function(){
    $("select.type").change(function(){
        var type = $(this).children("option:selected").val();
    });

    document.getElementById("type").innerHTML = window.carName;
});
</script>
    {!! Theme::js('js/frontend/serverlist.js') !!}
@endsection

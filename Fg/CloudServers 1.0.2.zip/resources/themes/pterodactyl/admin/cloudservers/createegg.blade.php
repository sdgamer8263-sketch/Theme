{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.admin')

@section('title')
    Cloud Servers
@endsection

@section('content-header')
@endsection

@section('content')
<div class="row">
<div class="col-md-12">
    <div class="box box-success">
        <div class="box-body">
        You are running on version <code>1.0.2</code> of the CloudServers Addon.
        </div>
    </div>
</div>
<div class="col-md-12" style="margin-bottom: 1%;">
    <div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.index') }}">
        <button style="width: 100%" class="btn btn-primary">Home</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.users') }}">
        <button style="width: 100%" class="btn btn-primary">Users</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.logs') }}">
        <button style="width: 100%" class="btn btn-primary">Logs</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.games') }}">
        <button style="width: 100%" class="btn btn-primary">Game's</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.changelogs') }}">
        <button style="width: 100%" class="btn btn-primary">ChangeLogs</button>
        </form>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>
</div>
<form method="POST" action="{{ route('admin.cloudservers.egg.create.2') }}">
<div class="box">
    <div class="box-body">
        <div class="row">
            <div class="col-md-8">
                <h4 style="color: black;">Name</h4>
                <input name="name" type="text" value="" class="form-control"></input>
                <p>Chouse the egg id for </p>
            </div>
            <div class="col-md-4">
                <h4 style="color: black;">Egg</h4>
                <select name="eggid" class="form-control">
                @foreach($eggs as $egg)
                    <option value="{{ $egg->id }}">{{ $egg->name }}</option>
                @endforeach
                </select>
                <p>Chouse the egg</p>
            </div>
            <div class="col-md-4">
                <h4 style="color: black;">Picture</h4>
                <input name="img" class="form-control"></input>
                <p>Chouse the egg picture</p>
            </div>
            <div class="col-md-8">
                <h4 style="color: black;">Egg Startup Premeter</h4>
                <input name="startup" class="form-control"></input>
                <p>Chouse the egg startup premeter</p>
            </div>
            <div class="col-md-12">
                <h4 style="color: black;">Egg Image</h4>
                <input name="image" class="form-control"></input>
                <p>Chouse the egg image</p>
            </div>
        </div>
        @csrf<button style="width: 100%; margin-top: 2%;" class="btn btn-success">Create</button>
    </div>
</div>
</form>
@endsection

@section('footer-scripts')
    @parent
    <script>
        $('tr.server-description').on('mouseenter mouseleave', function (event) {
            $(this).prev('tr').css({
                'background-color': (event.type === 'mouseenter') ? '#f5f5f5' : '',
            });
        });
    </script>

<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script>
$(document).ready(function(){
    $("select.type").change(function(){
        var type = $(this).children("option:selected").val();
    });

    document.getElementById("type").innerHTML = window.carName;
});
</script>
    {!! Theme::js('js/frontend/serverlist.js') !!}
@endsection

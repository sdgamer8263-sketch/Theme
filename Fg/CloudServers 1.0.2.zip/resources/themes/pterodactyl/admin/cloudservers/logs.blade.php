{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.admin')

@section('title')
    CloudServers
@endsection

@section('content-header')
@endsection

@section('content')
<div class="row">
<div class="col-md-12">
    <div class="box box-success">
        <div class="box-body">
        You are running on version <code>1.0.2</code> of the CloudServers Addon.
        </div>
    </div>
</div>
<div class="col-md-12" style="margin-bottom: 1%;">
    <div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.index') }}">
        <button style="width: 100%" class="btn btn-primary">Home</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.users') }}">
        <button style="width: 100%" class="btn btn-primary">Users</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.logs') }}">
        <button style="width: 100%" class="btn btn-primary">Logs</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.games') }}">
        <button style="width: 100%" class="btn btn-primary">Game's</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.changelogs') }}">
        <button style="width: 100%" class="btn btn-primary">ChangeLogs</button>
        </form>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>
</div>
<div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-file"></i> Cloud Server - Logs</h3>
                </div>
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tbody>
                        <tr>
                            <th>ID</th>
                            <th>Creator</th>
                            <th>Type</th>
                            <th>Ram</th>
                            <th>Disk</th>
                        </tr>
                        @if(!$logs->isEmpty())
                        @foreach($logs as $log)
                        <tr>
                            <th>{{ $log->id }}</th>
                            <th>{{ $log->creator }}</th>
                            <th>{{ $log->type }}</th>
                            <th>{{ $log->ram }}MB</th>
                            <th>{{ $log->disk }}MB</th>
                        </tr> 
                        @endforeach
                        @endif
                        @if($logs->isEmpty())
                        <tr>
                            <th></th>
                            <th></th>
                            
                            <th></th>
                            <th>No Logs Found</th> 
                            <th></th>
                        </tr> 
                        @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
</div>

@endsection

@section('footer-scripts')
    @parent
@endsection

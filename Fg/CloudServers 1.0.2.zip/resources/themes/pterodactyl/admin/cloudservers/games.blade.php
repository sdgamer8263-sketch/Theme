{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.admin')

@section('title')
    CloudServers
@endsection

@section('content-header')
@endsection

@section('content')
<div class="row">
<div class="col-md-12">
    <div class="box box-success">
        <div class="box-body">
        You are running on version <code>1.0.2</code> of the CloudServers Addon.
        </div>
    </div>
</div>
<div class="col-md-12" style="margin-bottom: 1%;">
    <div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.index') }}">
        <button style="width: 100%" class="btn btn-primary">Home</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.users') }}">
        <button style="width: 100%" class="btn btn-primary">Users</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.logs') }}">
        <button style="width: 100%" class="btn btn-primary">Logs</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.games') }}">
        <button style="width: 100%" class="btn btn-primary">Game's</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.changelogs') }}">
        <button style="width: 100%" class="btn btn-primary">ChangeLogs</button>
        </form>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>
<div class="col-md-12">
    <div>
        <div class="box-body">
        <form action="{{ route('admin.cloudservers.egg.create') }}">
             @csrf<button class="pull-right btn btn-success">Create New</button>
        </form>
        </div>
    </div>
</div>
@foreach($eggs as $egg)
<div class="col-md-4">
    <div class="box">
        <div class="box-body">
            <div class="row">
                <div class="col-md-3">
                    <img src="{{ $egg->img }}" width="125" alt="-" />
                </div>
                <div class="col-md-9" style="margin-top: 1%;"><br><br>
                    <div class="row">
                    <div class="col-md-5">
                    <h4>{{ $egg->name }}</h4>
                    </div>
                    <div class="col-md-7">
                    @if($egg->status == 0)
                    <form method="POST" action="{{ route('admin.cloudservers.egg.status') }}">
                    @csrf<button name="status" style="float: left;" value="{{ $egg->name }}" class="btn btn-primary">Enable</button>
                    </form>
                    @else
                    <form method="POST" action="{{ route('admin.cloudservers.egg.status') }}">
                    @csrf<button style="float: left; margin-right: 5%;" name="status" value="{{ $egg->name }}" class="btn btn-danger">Disable</button>
                    </form>
                    <form action="{{ route('admin.cloudservers.egg.settings', $egg->id) }}">
                    @csrf<button name="paper" value="0" style="background-color: #008ee0; border-color: #0073b5;" class="btn btn-danger">Settings</button>
                    </form>
                    @endif
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endforeach
</div>
@endsection

@section('footer-scripts')
    @parent
@endsection

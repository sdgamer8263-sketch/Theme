{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.admin')

@section('title')
    CloudServers
@endsection

@section('content-header')
<style>
input {
  width: 100%;
  height: 35px;
  padding: 7px 10px;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 12px;
  background-color: #f8f8f8;
  font-size: 15px;
  resize: none;
}

select {
  width: 100%;
  height: 35px;
  padding: 7px 10px;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 12px;
  background-color: #f8f8f8;
  font-size: 15px;
  resize: none;
}
</style>
@endsection

@section('content')
<div class="row">
<div class="col-md-12">
    <div class="box box-success">
        <div class="box-body">
        You are running on version <code>1.0.2</code> of the CloudServers Addon.
        </div>
    </div>
</div>
<div class="col-md-12" style="margin-bottom: 1%;">
    <div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.index') }}">
        <button style="width: 100%" class="btn btn-primary">Home</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.users') }}">
        <button style="width: 100%" class="btn btn-primary">Users</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.logs') }}">
        <button style="width: 100%" class="btn btn-primary">Logs</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.games') }}">
        <button style="width: 100%" class="btn btn-primary">Game's</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.changelogs') }}">
        <button style="width: 100%" class="btn btn-primary">ChangeLogs</button>
        </form>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>
<div class="col-md-9">
    <div class="box box-primary">
        <div style="text-align: center;" class="box-header with-border">
            Settings - CloudServers
        </div>
        <div class="box-body">
        <form method="POST" action="{{ route('admin.cloudservers.update') }}">
            <div class="row">
                <div class="col-md-12">
                <h4 style="color: gray;">Logs</h4>
                <select name="logs" class="form-control">
                @if($settings->logs == 1)
                <option selected value="1">Enabled</option>
                @else
                <option value="1">Enabled</option>
                @endif
                @if($settings->logs == 0)
                <option selected value="0">Disabled</option>
                @else
                <option value="0">Disabled</option>
                @endif
                </select>
                </div>
                <div class="col-md-3" style="margin-top: 1%;">
                <h4 style="color: gray;">Default CPU <small>(CPU %)</small></h4>
                <input name="cpu" type="number" value="{{ $settings->default_cpu }}" class="form-control"></input>
                </div>
                <div class="col-md-3" style="margin-top: 1%;">
                <h4 style="color: gray;">Default IO Block</h4>
                <input name="io" type="number" value="{{ $settings->default_io }}" class="form-control"></input>
                </div>
                <div class="col-md-3" style="margin-top: 1%;">
                <h4 style="color: gray;">Default Amount Database</h4>
                <input name="database" type="number"  value="{{ $settings->default_database }}" class="form-control"></input>
                </div>
                <div class="col-md-3" style="margin-top: 1%;">
                <h4 style="color: gray;">Default Allocation</h4>
                <input name="allocation" type="number" value="{{ $settings->default_allocation }}" class="form-control"></input>
                </div>
                <div class="col-md-3" style="margin-top: 1%;">
                <h4 style="color: gray;">Maximum Ram <small>(MB)</small></h4>
                <input name="maxram" type="number" value="{{ $settings->max_ram }}" class="form-control"></input>
                </div>
                <div class="col-md-3" style="margin-top: 1%;">
                <h4 style="color: gray;">Minimum Ram <small>(MB)</small></h4>
                <input name="minram" type="number" value="{{ $settings->min_ram }}" class="form-control"></input>
                </div>
                <div class="col-md-3" style="margin-top: 1%;">
                <h4 style="color: gray;">Maximum Disk <small>(MB)</small></h4>
                <input name="maxdisk" type="number" value="{{ $settings->max_disk }}" class="form-control"></input>
                </div>
                <div class="col-md-3" style="margin-top: 1%;">
                <h4 style="color: gray;">Minimum Disk <small>(MB)</small></h4>
                <input name="mindisk" type="number" value="{{ $settings->min_disk }}" class="form-control"></input>
                </div>
                <br>
            </div>
            @csrf<button style="margin-top: 2%; width: 100%" class="btn btn-success">Save</button>
        </form>
        </div>
    </div>
</div>
<div class="col-md-3">
    <div class="box box-primary">
        <div style="text-align: center;" class="box-header with-border">
            Stats - CloudServers
        </div>
        <div class="box-body">
            <span style="width: 100%" class="btn btn-primary">Total Servers Created: {{ $settings->totalservers }}</span>
            <span style="margin-top: 3%;width: 100%" class="btn btn-primary">Total Ram From Users: {{ $settings->totalram }}MB</span>
        </div>
    </div>
</div>
</div>

@endsection

@section('footer-scripts')
    @parent
@endsection

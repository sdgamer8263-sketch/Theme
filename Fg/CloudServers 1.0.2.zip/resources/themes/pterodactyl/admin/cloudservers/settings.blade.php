{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.admin')

@section('title')
    Cloud Servers
@endsection

@section('content-header')
@endsection

@section('content')
<div class="row">
<div class="col-md-12">
    <div class="box box-success">
        <div class="box-body">
        You are running on version <code>1.0.2</code> of the CloudServers Addon.
        </div>
    </div>
</div>
<div class="col-md-12" style="margin-bottom: 1%;">
    <div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.index') }}">
        <button style="width: 100%" class="btn btn-primary">Home</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.users') }}">
        <button style="width: 100%" class="btn btn-primary">Users</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.logs') }}">
        <button style="width: 100%" class="btn btn-primary">Logs</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.games') }}">
        <button style="width: 100%" class="btn btn-primary">Game's</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.changelogs') }}">
        <button style="width: 100%" class="btn btn-primary">ChangeLogs</button>
        </form>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>
</div>
@foreach($eggs as $egg)
<form method="POST" action="{{ route('admin.cloudservers.egg.settings.update', $egg->id) }}">
<div class="box">
    <div class="box-body">
        <div class="row">
            <div class="col-md-8">
                <h4 style="color: black;">Name</h4>
                <input name="name" type="text" value="{{ $egg->name }}" class="form-control"></input>
                <p>Chouse the egg id for {{ $egg->name }}</p>
            </div>
            <div class="col-md-4">
                <h4 style="color: black;">Picture</h4>
                <input name="img" value="{{ $egg->img }}" class="form-control"></input>
                <p>Chouse the egg picture for {{ $egg->name }}</p>
            </div>
            <div class="col-md-6">
                <h4 style="color: black;">Egg Startup</h4>
                <input name="startup" value="{{ $egg->startup }}" class="form-control"></input>
                <p>Chouse the egg startup for {{ $egg->name }}</p>
            </div>
            <div class="col-md-6">
                <h4 style="color: black;">Egg Image</h4>
                <input name="image" value="{{ $egg->image }}" class="form-control"></input>
                <p>Chouse the egg image for {{ $egg->name }}</p>
            </div>
            <div class="col-md-12">
                <h4 style="color: black;">Egg ID</h4>
                <input name="eggid" type="number" value="{{ $egg->id }}" class="form-control"></input>
                <p>Chouse the egg id for {{ $egg->name }}</p>
            </div>
        </div>
        @csrf<button style="width: 100%; margin-top: 2%;" class="btn btn-warning">Update</button>
    </div>
</div>
</form>
@endforeach
@endsection

@section('footer-scripts')
    @parent
    <script>
        $('tr.server-description').on('mouseenter mouseleave', function (event) {
            $(this).prev('tr').css({
                'background-color': (event.type === 'mouseenter') ? '#f5f5f5' : '',
            });
        });
    </script>

<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script>
$(document).ready(function(){
    $("select.type").change(function(){
        var type = $(this).children("option:selected").val();
    });

    document.getElementById("type").innerHTML = window.carName;
});
</script>
    {!! Theme::js('js/frontend/serverlist.js') !!}
@endsection

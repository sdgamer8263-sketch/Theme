{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.admin')

@section('title')
    CloudServers
@endsection

@section('content-header')
@endsection

@section('content')
<div class="row">
<div class="col-md-12">
    <div class="box box-success">
        <div class="box-body">
        You are running on version <code>1.0.2</code> of the CloudServers Addon.
        </div>
    </div>
</div>
<div class="col-md-12" style="margin-bottom: 1%;">
    <div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.index') }}">
        <button style="width: 100%" class="btn btn-primary">Home</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.users') }}">
        <button style="width: 100%" class="btn btn-primary">Users</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.logs') }}">
        <button style="width: 100%" class="btn btn-primary">Logs</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.games') }}">
        <button style="width: 100%" class="btn btn-primary">Game's</button>
        </form>
        </div>
        <div class="col-md-2">
        <form action="{{ route('admin.cloudservers.changelogs') }}">
        <button style="width: 100%" class="btn btn-primary">ChangeLogs</button>
        </form>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>
<div class="col-md-12">
    <div class="box box-primary">
        <div style="text-align: center;" class="box-header with-border">
            Version V1.0.1
        </div>
        <div class="box-body">
            <span style="width: 100%; margin-top: 0.5%;" class="btn btn-primary">Discord Bot's</span>
            <span style="width: 100%; margin-top: 0.5%;" class="btn btn-primary">Added More Settings</span>
            <span style="width: 100%; margin-top: 0.5%;" class="btn btn-primary">Layout update User Page</span>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="box box-primary">
        <div style="text-align: center;" class="box-header with-border">
            Version V1.0.2
        </div>
        <div class="box-body">
            <span style="width: 100%; margin-top: 0.5%;" class="btn btn-primary">Add Your Own Games</span>
            <span style="width: 100%; margin-top: 0.5%;" class="btn btn-primary">Ram & Disk on the game configuration updates in real time</span>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="box box-primary">
        <div style="text-align: center;" class="box-header with-border">
            Version V1.0.3
        </div>
        <div class="box-body">
            <span style="width: 100%; margin-top: 0.5%;" class="btn btn-primary">Not released yet</span>
        </div>
    </div>
</div>
</div>

@endsection

@section('footer-scripts')
    @parent
@endsection

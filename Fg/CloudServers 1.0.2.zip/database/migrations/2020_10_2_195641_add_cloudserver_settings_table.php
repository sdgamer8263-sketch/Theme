<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddCloudserverSettingsTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('cloudsettings', function (Blueprint $table) {
            $table->increments('id');
            $table->string('systeem')->default(1);
            $table->string('default_cpu')->default(100);
            $table->string('default_io')->default(500);
            $table->string('default_allocation')->default(0);
            $table->string('default_database')->default(0);
            $table->string('max_ram')->default(0);
            $table->string('min_ram')->default(0);
            $table->string('min_disk')->default(0);
            $table->string('max_disk')->default(0);
            $table->string('logs')->default(1);
            $table->string('totalservers')->default(0);
            $table->string('totalram')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::table('cloudsettings', function (Blueprint $table) {
            $table->dropColumn('systeem');
            $table->dropColumn('logs');
            $table->dropColumn('default_cpu');
            $table->dropColumn('default_io');
            $table->dropColumn('default_allocation');
            $table->dropColumn('default_database');
            $table->dropColumn('max_ram');
            $table->dropColumn('min_ram');
            $table->dropColumn('min_disk');
            $table->dropColumn('max_disk');
            $table->dropColumn('totalservers');
            $table->dropColumn('totalram');
        });
    }
}

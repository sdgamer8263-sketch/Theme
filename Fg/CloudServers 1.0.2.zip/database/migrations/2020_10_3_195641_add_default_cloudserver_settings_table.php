<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddDefaultCloudserverSettingsTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        DB::table('cloudsettings')->insert(
            array(
                'default_io' => (int) 500,
                'default_cpu' => (int) 200,
                'default_database' => (int) 1,
                'default_allocation' => (int) 0,
                'min_ram' => (int) 100,
                'max_ram' => (int) 10000,
                'min_disk' => (int) 5000,
                'max_disk' => (int) 100000,
                'logs' => (int) 1,
            )
        );
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
      DB::table('cloudsettings')->where('id', '=', '1')->delete();
    }
}

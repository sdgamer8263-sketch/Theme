<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddCloudserverTypesTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('cloudeggs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('img');
            $table->string('description');
            $table->string('status')->default(1);
            $table->string('startup');
            $table->string('image');
            $table->string('eggid');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::table('cloudeggs', function (Blueprint $table) {
            $table->dropColumn('id');
            $table->dropColumn('name');
            $table->dropColumn('img');
            $table->dropColumn('description');
            $table->dropColumn('status');
            $table->dropColumn('startup');
            $table->dropColumn('image');
            $table->dropColumn('eggid');
        });
    }
}

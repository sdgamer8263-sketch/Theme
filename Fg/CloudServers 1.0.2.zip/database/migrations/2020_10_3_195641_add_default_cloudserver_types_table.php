<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddDefaultCloudserverTypesTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        DB::table('cloudeggs')->insert(
            array(
                'img' => '/cloudservers/img/Paper.png',
                'name' => 'Minecraft Paper',
                'description' => 'Paper is the next generation of Minecraft server, compatible with Spigot plugins and offering uncompromising performance.',
                'status' => (int) 1,
                'eggid' => (int) 3,
                'image' => 'quay.io/pterodactyl/core:java',
                'startup' => 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}',
            )
        );
        DB::table('cloudeggs')->insert(
            array(
                'img' => '/cloudservers/img/Bungeecord.png',
                'name' => 'Minecraft Bungeecord',
                'description' => 'BungeeCord is a useful software written in-house by the team at SpigotMC. It acts as a proxy between the players client and the connected Minecraft servers. End-users of BungeeCord see no difference between it and a normal Minecraft server.',
                'status' => (int) 1,
                'eggid' => (int) 1,
                'image' => 'quay.io/pterodactyl/core:java',
                'startup' => 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}',
            )
        );
        DB::table('cloudeggs')->insert(
            array(
                'img' => '/cloudservers/img/DiscordBot.png',
                'name' => 'Discord Bot',
                'description' => 'Integrate your service with Discord whether its a bot or a game or whatever your wildest imagination can come up with.',
                'status' => (int) 0,
                'eggid' => (int) 0,
                'image' => 'Not Set',
                'startup' => 'Not Set',
            )
        );
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
      DB::table('cloudeggs')->delete();
    }
}
